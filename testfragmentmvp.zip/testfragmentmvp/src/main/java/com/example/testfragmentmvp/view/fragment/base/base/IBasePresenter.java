package com.example.testfragmentmvp.view.fragment.base.base;

/**
 * Created by AndroidXJ on 2019/2/18.
 */

public interface IBasePresenter {
    void getFragmentName();

    void setFragmentNamr(String name);
}
