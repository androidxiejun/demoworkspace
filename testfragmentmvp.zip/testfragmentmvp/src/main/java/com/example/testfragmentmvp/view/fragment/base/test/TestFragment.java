package com.example.testfragmentmvp.view.fragment.base.test;

import com.example.testfragmentmvp.view.fragment.base.base.BaseFragment;

/**
 * Created by AndroidXJ on 2019/2/18.
 */

public class TestFragment extends BaseFragment<TestContract.View,TestContract.Presenter>implements TestContract.View {
    @Override
    public void showResult(int num) {

    }

    @Override
    protected int getLayoutId() {
        return 0;
    }

    @Override
    protected void init() {

    }
}
